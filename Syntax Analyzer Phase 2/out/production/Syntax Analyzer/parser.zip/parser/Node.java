package parser;

public interface Node {
    public void printNode();
}
