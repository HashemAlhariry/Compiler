package parser;

public class Param_list_ implements Node{
    Token comma;
    Param param;
    Param_list_ param_list_;

    @Override
    public void printNode() {

    }
}
