package parser;

public class Stmt_list implements Node{
    Stmt_list_ stmt_list_;
    @Override
    public void printNode() {

    }
}
