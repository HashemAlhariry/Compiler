package parser;

public class Var_decl implements Node {

    Type_spec type_spec;
    Token ident;
    B b;

    @Override
    public void printNode() {

    }
}
