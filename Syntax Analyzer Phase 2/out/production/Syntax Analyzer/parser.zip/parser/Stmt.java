package parser;

public class Stmt implements Node {

    Expr_stmt expr_stmt;
    Compound_stmt compound_stmt;
    If_stmt if_stmt;
    While_stmt while_stmt;
    Return_stmt return_stmt;
    Token break_stmt;
    @Override
    public void printNode() {

    }

}
