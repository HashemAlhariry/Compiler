package parser;

public class Type_spec  implements Node{

    Token int_;
    Token void_;
    Token bool_;
    Token float_;

    @Override
    public void printNode() {

    }
}
