package parser;

public class Local_decl {
}
