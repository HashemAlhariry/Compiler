package parser;

public class Local_decls_ {
}
