package parser;

public class Compound_stmt implements Node {
    Token right_curly_b;
    Token left_curly_b;
    Local_decls local_decls;
    Stmt_list stmt_list;

    @Override
    public void printNode() {

    }
}
