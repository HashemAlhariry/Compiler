package parser;

public class Program implements Node {
    Decl_list decl_list;
    @Override
    public void printNode() {

    }

}
