package parser;

public class Func_decl implements Node {

    Type_spec type_spec;
    Token ident;
    Token right_round_b;
    Params params;
    Token left_round_b;
    Compound_stmt compound_stmt;
    @Override
    public void printNode() {

    }
}
