package parser;

public class B  implements  Node{
    Token leftsquarebrac;
    Token rightsquarebrac;
    Token semicolon;
    @Override
    public void printNode() {

    }
}
