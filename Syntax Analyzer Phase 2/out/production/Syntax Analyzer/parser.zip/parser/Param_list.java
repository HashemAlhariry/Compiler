package parser;

public class Param_list implements  Node{
    Param param;
    Param_list_ param_list_;
    @Override
    public void printNode() {

    }
}
