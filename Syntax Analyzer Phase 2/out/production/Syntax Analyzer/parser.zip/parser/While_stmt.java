package parser;

public class While_stmt implements Node {
    Token while_;
    Token left_round_b;
    Token right_round_b;
    Stmt stmt;

    @Override
    public void printNode() {

    }
}
