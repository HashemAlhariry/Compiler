package parser;

public class Parser implements Node {
    @Override
    public void printNode() {

    }


}
