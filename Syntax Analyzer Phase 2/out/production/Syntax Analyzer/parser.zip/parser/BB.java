package parser;

public class BB implements Node {
    Token leftsquarebracket;
    Token rightsquarebracket;

    @Override
    public void printNode() {

    }
}
