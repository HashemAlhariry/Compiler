package parser;

public class Param implements Node {
    Type_spec type_spec;
    Token ident;
    BB bb;

    @Override
    public void printNode() {

    }
}
