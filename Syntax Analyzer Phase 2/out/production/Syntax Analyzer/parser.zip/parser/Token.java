package parser;

public class Token {
}
