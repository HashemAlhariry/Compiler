package parser;

public class Decl_list_ implements Node {

    Decl decl;
    Decl_list_ decl_list_;
    @Override
    public void printNode() {

    }
}
