package parser;

public class Expr_stmt  implements  Node{

    Expr expr;
    Token semicolon;

    @Override
    public void printNode() {

    }
}
