package parser;

public class Decl implements Node{
        Var_decl var_decl;
        Func_decl func_decl;
    @Override
    public void printNode() {

    }
}
