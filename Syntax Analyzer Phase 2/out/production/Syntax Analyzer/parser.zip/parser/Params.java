package parser;

public class Params implements  Node{

    Param_list param_list;
    Token void_;
    @Override
    public void printNode() {

    }
}
