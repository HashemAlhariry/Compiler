package parser;

public class Stmt_list_ implements Node{
   Stmt stmt;
   Stmt_list_ stmt_list_;

    @Override
    public void printNode() {

    }
}
